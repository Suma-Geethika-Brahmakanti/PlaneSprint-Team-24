function enroll(){
    document.getElementById("view").innerHTML="Congragulations! You have enrolled to this course <br> Happy Learning!!";
    document.getElementsByClassName("enroll")[0].innerHTML="Enrolled";
}